
You need to populate this directory with the static version of the zlib library.
See the instructions in file ..\README.txt
