The CONLL2000 files go here.
See ../README.
